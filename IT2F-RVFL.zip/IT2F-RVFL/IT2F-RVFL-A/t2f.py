import numpy as np


class IT2FFeatureMap:
    """Fixed interval type-2 membership-based randomized feature map.

    For N input features and U fuzzy rules, this map returns U IT2F features
    for each sample, so F has shape (M, U).

    The membership parameters and lower/upper randomized branch projections
    are generated once and remain fixed thereafter.
    """

    def __init__(self, rule_num: int, seed: int = 42, eps: float = 1e-12):
        if rule_num <= 0:
            raise ValueError("rule_num must be positive.")
        self.rule_num = int(rule_num)
        self.seed = int(seed)
        self.eps = float(eps)
        self._fitted = False

    def fit(self, input_dim: int):
        if input_dim <= 0:
            raise ValueError("input_dim must be positive.")

        self.input_dim = int(input_dim)
        rng = np.random.default_rng(self.seed)

        # Uncertain-mean Gaussian membership parameters.
        self.center_low = rng.uniform(
            0.0, 0.5, size=(self.input_dim, self.rule_num)
        )
        self.center_high = rng.uniform(
            0.5, 1.0, size=(self.input_dim, self.rule_num)
        )
        self.width = np.full((self.input_dim, self.rule_num), 0.5, dtype=float)

        # Fixed randomized lower/upper branch projections.
        # Shape U x U so the IT2F output dimension is U.
        self.W_lower = rng.uniform(0.0, 1.0, size=(self.rule_num, self.rule_num))
        self.W_upper = rng.uniform(0.0, 1.0, size=(self.rule_num, self.rule_num))

        self._fitted = True
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        if not self._fitted:
            raise RuntimeError("Call fit(input_dim) before transform(X).")

        X = np.asarray(X, dtype=float)
        if X.ndim == 1:
            X = X.reshape(1, -1)
        if X.ndim != 2 or X.shape[1] != self.input_dim:
            raise ValueError(
                f"Expected X with shape (M, {self.input_dim}), got {X.shape}."
            )

        # Shapes: x -> (M, N, 1), centers/width -> (1, N, U)
        x = X[:, :, None]
        c_low = self.center_low[None, :, :]
        c_high = self.center_high[None, :, :]
        width = self.width[None, :, :]

        gauss_low = np.exp(-((x - c_low) ** 2) / (2.0 * width**2))
        gauss_high = np.exp(-((x - c_high) ** 2) / (2.0 * width**2))

        # Upper membership function: unity plateau between uncertain means.
        upper_mf = np.where(
            x < c_low,
            gauss_low,
            np.where(x <= c_high, 1.0, gauss_high),
        )

        # Lower membership function: intersection of the two Gaussian tails.
        midpoint = 0.5 * (c_low + c_high)
        lower_mf = np.where(x <= midpoint, gauss_high, gauss_low)

        # Product t-norm across input dimensions -> (M, U).
        upper_fire = np.prod(upper_mf, axis=1)
        lower_fire = np.prod(lower_mf, axis=1)

        # Fixed randomized branch responses.
        upper_weighted = upper_fire @ self.W_upper
        lower_weighted = lower_fire @ self.W_lower

        # Normalize each branch by its own total firing strength.
        upper_norm = upper_weighted / (
            np.sum(upper_fire, axis=1, keepdims=True) + self.eps
        )
        lower_norm = lower_weighted / (
            np.sum(lower_fire, axis=1, keepdims=True) + self.eps
        )

        # Arithmetic midpoint aggregation; no type-reduction claim is made.
        return 0.5 * (lower_norm + upper_norm)

    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=float)
        if X.ndim == 1:
            X = X.reshape(1, -1)
        self.fit(X.shape[1])
        return self.transform(X)


# Backward-compatible one-shot helper. For train/test use, prefer the class
# above so the SAME fixed parameters are used for both sets.
def t2f_f(X, RuleNum, seed=42):
    mapper = IT2FFeatureMap(rule_num=RuleNum, seed=seed)
    return mapper.fit_transform(X)
