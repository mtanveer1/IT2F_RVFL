
from __future__ import annotations

import numpy as np

from t2f import IT2FFeatureMap
from rvfl_adaptive import RecursiveRidge


def _closed_ridge(Z, Y, alpha):
    Z = np.asarray(Z, dtype=float)
    Y = np.asarray(Y, dtype=float)
    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    d = Z.shape[1]
    return np.linalg.solve(Z.T @ Z + float(alpha) * np.eye(d), Z.T @ Y)


class _IT2FRVFLBase:
    def __init__(
        self,
        n_rules=10,
        n_hidden=50,
        activation=1,
        alpha=1.0,
        seed=42,
        scale_inputs=True,
    ):
        if int(n_rules) <= 0 or int(n_hidden) <= 0:
            raise ValueError("n_rules and n_hidden must be positive.")
        if float(alpha) <= 0:
            raise ValueError("alpha must be strictly positive.")
        self.n_rules = int(n_rules)
        self.n_hidden = int(n_hidden)
        self.activation = activation
        self.alpha = float(alpha)
        self.seed = int(seed)
        self.scale_inputs = bool(scale_inputs)
        self._fitted = False

    def _fit_scaler(self, X):
        self.x_min_ = np.min(X, axis=0)
        self.x_max_ = np.max(X, axis=0)
        self.x_range_ = self.x_max_ - self.x_min_
        self.x_range_[np.abs(self.x_range_) < 1e-15] = 1.0

    def _transform_inputs(self, X):
        X = np.asarray(X, dtype=float)
        if not self.scale_inputs:
            return X
        return (X - self.x_min_) / self.x_range_

    def _activate(self, A):
        if self.activation in (1, "sigmoid"):
            A = np.clip(A, -60.0, 60.0)
            return 1.0 / (1.0 + np.exp(-A))
        if self.activation in (2, "sine"):
            return np.sin(A)
        if self.activation in (3, "tribas"):
            return np.maximum(0.0, 1.0 - np.abs(A))
        if self.activation in (4, "radbas"):
            return np.exp(-(A ** 2))
        if self.activation in (5, "tanh", "tansig"):
            return np.tanh(A)
        if self.activation in (6, "relu"):
            return np.maximum(0.0, A)
        raise ValueError(f"Unsupported activation: {self.activation}")

    def _hidden_features(self, X_scaled, F):
        X_comb = np.hstack([X_scaled, F])
        return self._activate(X_comb @ self.hidden_W_ + self.hidden_b_)

    def _fit_feature_map(self, X):
        X = np.asarray(X, dtype=float)
        if X.ndim != 2:
            raise ValueError("X must be a 2D array.")
        self.n_inputs_ = X.shape[1]

        if self.scale_inputs:
            self._fit_scaler(X)
        else:
            self.x_min_ = np.zeros(self.n_inputs_)
            self.x_max_ = np.ones(self.n_inputs_)
            self.x_range_ = np.ones(self.n_inputs_)

        Xs = self._transform_inputs(X)

        self.it2f_map_ = IT2FFeatureMap(
            rule_num=self.n_rules,
            seed=self.seed,
        ).fit(self.n_inputs_)
        F = self.it2f_map_.transform(Xs)

        rng = np.random.default_rng(self.seed + 1)
        hidden_input_dim = self.n_inputs_ + self.n_rules
        self.hidden_W_ = rng.uniform(
            -1.0, 1.0, size=(hidden_input_dim, self.n_hidden)
        )
        self.hidden_b_ = rng.uniform(0.0, 1.0, size=(self.n_hidden,))

        H = self._hidden_features(Xs, F)
        Z = np.hstack([Xs, F, H])
        self.d_ = Z.shape[1]
        return Z

    def _features(self, X):
        X = np.asarray(X, dtype=float)
        if X.ndim == 1:
            X = X.reshape(1, -1)
        Xs = self._transform_inputs(X)
        F = self.it2f_map_.transform(Xs)
        H = self._hidden_features(Xs, F)
        return np.hstack([Xs, F, H])

    def predict(self, X):
        if not self._fitted:
            raise RuntimeError("Call fit(...) before predict(...).")
        return self._features(X) @ self.W_


class IT2FRVFLC(_IT2FRVFLBase):
    """IT2F-RVFL-C: fixed randomized features + closed-form ridge."""

    def fit(self, X, Y):
        Y = np.asarray(Y, dtype=float)
        if Y.ndim == 1:
            Y = Y.reshape(-1, 1)
        Z = self._fit_feature_map(X)
        if Z.shape[0] != Y.shape[0]:
            raise ValueError("X and Y must have matching sample counts.")
        self.n_outputs_ = Y.shape[1]
        self.W_ = _closed_ridge(Z, Y, self.alpha)
        self._fitted = True
        return self


class IT2FRVFLA(_IT2FRVFLBase):
    """IT2F-RVFL-A: fixed randomized features + fixed-alpha recursive ridge."""

    def fit(self, X, Y):
        Y = np.asarray(Y, dtype=float)
        if Y.ndim == 1:
            Y = Y.reshape(-1, 1)
        Z = self._fit_feature_map(X)
        if Z.shape[0] != Y.shape[0]:
            raise ValueError("X and Y must have matching sample counts.")
        self.n_outputs_ = Y.shape[1]
        self.recursive_ridge_ = RecursiveRidge(alpha=self.alpha).fit(Z, Y)
        self.W_ = self.recursive_ridge_.W.copy()
        self.P_ = self.recursive_ridge_.P.copy()
        self._fitted = True
        return self

    def partial_fit_one(self, x, y):
        if not self._fitted:
            raise RuntimeError("Call fit(...) before partial_fit_one(...).")
        z = self._features(np.asarray(x).reshape(1, -1))
        self.recursive_ridge_.partial_fit(z[0], y)
        self.W_ = self.recursive_ridge_.W.copy()
        self.P_ = self.recursive_ridge_.P.copy()
        return self
