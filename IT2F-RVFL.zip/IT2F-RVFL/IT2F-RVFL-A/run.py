"""IT2F-RVFL-A only, four systems, archived validation-selected hyperparameters.
Output test predictions are recalculated; archived test numbers are never substituted.
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[k] = '1'
import argparse, csv, json, time
from pathlib import Path
import numpy as np
from all_dynamical_systems import SYSTEM_NAMES, load_system
from it2f_rvfl_models import IT2FRVFLA

ROOT=Path(__file__).resolve().parent
FIELDS=['System','Model','TrainSamples','TestSamples','InputDim','Rules','Hidden','Activation','ActivationName','Alpha','ValidationRMSE','TestRMSE','TestMAE','TestNRMSE','TestMAPEPercent','TrainTimeSec','UpdateTimeMsPerTrainSample','TestTimeSec','BatchRecursiveMaxAbsPredictionDiff']
ACT={1:'sigmoid',2:'sine',3:'tribas',4:'radbas',5:'tanh',6:'relu'}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--systems',nargs='+',default=list(SYSTEM_NAMES),choices=SYSTEM_NAMES)
    p.add_argument('--output',default='reproduced_results.csv')
    a=p.parse_args()
    configs=json.loads((ROOT/'selected_hyperparameters.json').read_text())
    rows=[]
    for system in a.systems:
        xtr,ytr,xte,yte=load_system(system); cfg=configs[system]
        model=IT2FRVFLA(n_rules=cfg['n_rules'],n_hidden=cfg['n_hidden'],activation=cfg['activation'],alpha=cfg['alpha'],seed=42)
        t=time.perf_counter();model.fit(xtr,ytr);train_t=time.perf_counter()-t
        t=time.perf_counter();pred=model.predict(xte);test_t=time.perf_counter()-t
        err=np.asarray(pred)-np.asarray(yte)
        rmse=float(np.sqrt(np.mean(err**2))); mae=float(np.mean(abs(err)))
        sd=float(np.std(yte));nrmse=rmse/sd if sd>=1e-12 else float('nan')
        mape=float(np.mean(np.abs(err)/np.maximum(np.abs(yte),1e-8))*100)
        # Diagnostic only; direct solve may differ from recursive updates at very small alpha.
        ztr=model._features(xtr);zte=model._features(xte)
        d=ztr.T@ztr+float(cfg['alpha'])*np.eye(ztr.shape[1]); b=ztr.T@ytr
        try: batch=np.linalg.solve(d,b); diff=float(np.max(np.abs(zte@batch-pred)))
        except np.linalg.LinAlgError: diff=float('nan')
        row=dict(System=system,Model='IT2F-RVFL-A',TrainSamples=len(xtr),TestSamples=len(xte),InputDim=xtr.shape[1],Rules=cfg['n_rules'],Hidden=cfg['n_hidden'],Activation=cfg['activation'],ActivationName=ACT[cfg['activation']],Alpha=cfg['alpha'],ValidationRMSE=cfg['validation_rmse'],TestRMSE=rmse,TestMAE=mae,TestNRMSE=nrmse,TestMAPEPercent=mape,TrainTimeSec=train_t,UpdateTimeMsPerTrainSample=1000*train_t/len(xtr),TestTimeSec=test_t,BatchRecursiveMaxAbsPredictionDiff=diff)
        rows.append(row)
        print(f"{system:22} RMSE={rmse:.12g} MAE={mae:.12g} NRMSE={nrmse:.12g}",flush=True)
    with open(a.output,'w',newline='') as f:
        w=csv.DictWriter(f,FIELDS);w.writeheader();w.writerows(rows)
    print('Saved:',a.output)
if __name__=='__main__':main()
