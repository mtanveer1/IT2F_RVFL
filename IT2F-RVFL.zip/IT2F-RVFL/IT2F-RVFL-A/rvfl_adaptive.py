import numpy as np


class RecursiveRidge:
    """Fixed-regularization recursive ridge regression.

    Implements
        P_0 = alpha^{-1} I,
        W_0 = 0,
        k_n = P_{n-1} z_n^T / (1 + z_n P_{n-1} z_n^T),
        e_n = y_n - z_n W_{n-1},
        W_n = W_{n-1} + k_n e_n,
        P_n = P_{n-1} - k_n z_n P_{n-1}.

    For fixed features and alpha > 0, this is exactly equivalent to the
    corresponding batch ridge-regression solution after each observation.
    """

    def __init__(self, alpha: float = 1.0, symmetrize: bool = True):
        if alpha <= 0:
            raise ValueError("alpha must be strictly positive.")
        self.alpha = float(alpha)
        self.symmetrize = bool(symmetrize)
        self._initialized = False

    def initialize(self, n_features: int, n_outputs: int):
        if n_features <= 0 or n_outputs <= 0:
            raise ValueError("n_features and n_outputs must be positive.")

        self.n_features = int(n_features)
        self.n_outputs = int(n_outputs)
        self.P = np.eye(self.n_features, dtype=float) / self.alpha
        self.W = np.zeros((self.n_features, self.n_outputs), dtype=float)
        self.n_seen = 0
        self._initialized = True
        return self

    def partial_fit(self, z: np.ndarray, y: np.ndarray):
        if not self._initialized:
            raise RuntimeError("Call initialize(...) before partial_fit(...).")

        z = np.asarray(z, dtype=float).reshape(1, -1)
        y = np.asarray(y, dtype=float).reshape(1, -1)

        if z.shape[1] != self.n_features:
            raise ValueError(
                f"Expected z with {self.n_features} features, got {z.shape[1]}."
            )
        if y.shape[1] != self.n_outputs:
            raise ValueError(
                f"Expected y with {self.n_outputs} outputs, got {y.shape[1]}."
            )

        P_prev = self.P
        W_prev = self.W

        # Symmetric Sherman-Morrison form.  Using u @ u.T rather than
        # k @ z @ P materially reduces loss of symmetry for very small alpha.
        u = P_prev @ z.T                              # (d, 1)
        denom = 1.0 + (z @ u).item()
        if (not np.isfinite(denom)) or denom <= 0.0:
            raise FloatingPointError(
                "Recursive ridge denominator became non-positive/non-finite. "
                "The selected alpha is numerically unstable for this feature map."
            )

        k = u / denom                                 # (d, 1)
        error = y - z @ W_prev                        # (1, C)
        self.W = W_prev + k @ error                    # (d, C)
        self.P = P_prev - (u @ u.T) / denom            # (d, d)

        # Suppress tiny asymmetry caused by floating-point roundoff.
        if self.symmetrize:
            self.P = 0.5 * (self.P + self.P.T)

        self.n_seen += 1
        return self

    def fit(self, Z: np.ndarray, Y: np.ndarray):
        Z = np.asarray(Z, dtype=float)
        Y = np.asarray(Y, dtype=float)
        if Y.ndim == 1:
            Y = Y.reshape(-1, 1)
        if Z.ndim != 2 or Y.ndim != 2 or Z.shape[0] != Y.shape[0]:
            raise ValueError("Z and Y must be 2D arrays with matching rows.")

        self.initialize(Z.shape[1], Y.shape[1])
        for n in range(Z.shape[0]):
            self.partial_fit(Z[n], Y[n])
        return self

    def predict(self, Z: np.ndarray) -> np.ndarray:
        if not self._initialized:
            raise RuntimeError("Model is not initialized.")
        Z = np.asarray(Z, dtype=float)
        if Z.ndim == 1:
            Z = Z.reshape(1, -1)
        return Z @ self.W


# Compatibility helper replacing the old adaptive lambda/eta routine.
def train_adaptive(
    X_train: np.ndarray,
    Y_train: np.ndarray,
    Z: np.ndarray,
    alpha: float = 1.0,
) -> np.ndarray:
    """Return fixed-alpha recursive-ridge output weights.

    X_train is retained only for API compatibility with the earlier code.
    The update itself depends on the enhanced feature matrix Z and targets Y.
    """
    del X_train
    model = RecursiveRidge(alpha=alpha).fit(Z, Y_train)
    return model.W
