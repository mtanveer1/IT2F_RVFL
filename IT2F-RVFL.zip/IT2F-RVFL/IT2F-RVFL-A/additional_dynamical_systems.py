import numpy as np

def _chronological_split(X, Y, n_train=5000, n_test=200):
    """Return the first n_train samples for training and the next n_test for test."""
    X = np.asarray(X, dtype=float)
    Y = np.asarray(Y, dtype=float)

    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)

    required = n_train + n_test
    if X.shape[0] < required or Y.shape[0] < required:
        raise ValueError(
            f"Need at least {required} supervised samples, "
            f"but received X={X.shape[0]}, Y={Y.shape[0]}."
        )

    return (
        X[:n_train],
        Y[:n_train],
        X[n_train:n_train + n_test],
        Y[n_train:n_train + n_test],
    )

def generate_mackey_glass(
    n_train=5000,
    n_test=200,
    beta=0.2,
    gamma=0.1,
    exponent=10,
    tau=17,
    dt=1.0,
    warmup=1000,
    x0=1.2,
    prediction_horizon=6,
    lags=(0, 6, 12, 18),
):
    r"""
    Mackey-Glass delayed nonlinear system:

        dx(t)/dt =
            beta*x(t-tau)/(1 + x(t-tau)^exponent)
            - gamma*x(t)

    The delay equation is simulated using an Euler discretization.

    Default supervised representation:
        [x(t), x(t-6), x(t-12), x(t-18)] -> x(t+6)

    Returns
    -------
    trainX : (n_train, len(lags))
    trainY : (n_train, 1)
    testX  : (n_test, len(lags))
    testY  : (n_test, 1)
    """
    if tau <= 0:
        raise ValueError("tau must be positive.")
    if dt <= 0:
        raise ValueError("dt must be positive.")
    if prediction_horizon <= 0:
        raise ValueError("prediction_horizon must be positive.")

    lags = tuple(int(v) for v in lags)
    if min(lags) < 0:
        raise ValueError("lags must be nonnegative.")

    total_supervised = n_train + n_test
    max_lag = max(lags)

    # Enough data for transient removal, delayed features, and future target.
    total_steps = (
        warmup
        + total_supervised
        + max_lag
        + prediction_horizon
        + tau
        + 2
    )

    x = np.full(total_steps, float(x0), dtype=float)

    # History x(t)=x0 is used for the initial delayed interval.
    for t in range(tau, total_steps - 1):
        delayed = x[t - tau]
        derivative = (
            beta * delayed / (1.0 + delayed ** exponent)
            - gamma * x[t]
        )
        x[t + 1] = x[t] + dt * derivative

    start_t = warmup + max_lag + tau
    X = np.empty((total_supervised, len(lags)), dtype=float)
    Y = np.empty((total_supervised, 1), dtype=float)

    for j in range(total_supervised):
        t = start_t + j
        X[j, :] = [x[t - lag] for lag in lags]
        Y[j, 0] = x[t + prediction_horizon]

    return _chronological_split(X, Y, n_train, n_test)

def _lorenz_rhs(state, sigma, rho, beta):
    x, y, z = state
    return np.array(
        [
            sigma * (y - x),
            x * (rho - z) - y,
            x * y - beta * z,
        ],
        dtype=float,
    )

def _rk4_step(state, dt, rhs, *rhs_args):
    """One fourth-order Runge-Kutta step."""
    k1 = rhs(state, *rhs_args)
    k2 = rhs(state + 0.5 * dt * k1, *rhs_args)
    k3 = rhs(state + 0.5 * dt * k2, *rhs_args)
    k4 = rhs(state + dt * k3, *rhs_args)
    return state + (dt / 6.0) * (k1 + 2*k2 + 2*k3 + k4)

def generate_lorenz(
    n_train=5000,
    n_test=200,
    sigma=10.0,
    rho=28.0,
    beta=8.0 / 3.0,
    dt=0.01,
    warmup=2000,
    initial_state=(1.0, 1.0, 1.0),
    target="all",
):
    r"""
    Lorenz chaotic system:

        dx/dt = sigma (y - x)
        dy/dt = x (rho - z) - y
        dz/dt = x y - beta z

    Default parameters:
        sigma=10, rho=28, beta=8/3

    Supervised representations:
        target="all":
            [x(t), y(t), z(t)] -> [x(t+1), y(t+1), z(t+1)]

        target="x":
            [x(t), y(t), z(t)] -> x(t+1)

    Integration uses fourth-order Runge-Kutta.

    Returns
    -------
    trainX : (n_train, 3)
    trainY : (n_train, 3) if target="all", else (n_train, 1)
    testX  : (n_test, 3)
    testY  : corresponding target shape
    """
    if dt <= 0:
        raise ValueError("dt must be positive.")
    if target not in {"all", "x"}:
        raise ValueError("target must be 'all' or 'x'.")

    total_supervised = n_train + n_test
    total_steps = warmup + total_supervised + 1

    states = np.empty((total_steps, 3), dtype=float)
    states[0] = np.asarray(initial_state, dtype=float)

    for t in range(total_steps - 1):
        states[t + 1] = _rk4_step(
            states[t], dt, _lorenz_rhs, sigma, rho, beta
        )

    s = states[warmup:]
    X = s[:-1]

    if target == "all":
        Y = s[1:]
    else:
        Y = s[1:, 0:1]

    return _chronological_split(X, Y, n_train, n_test)

def generate_narma10(
    n_train=5000,
    n_test=200,
    warmup=500,
    seed=42,
    input_low=0.0,
    input_high=0.5,
    order=10,
):
    r"""
    NARMA-10 nonlinear memory system:

        y(t+1) =
            0.3*y(t)
            + 0.05*y(t)*sum_{i=0}^{9} y(t-i)
            + 1.5*u(t-9)*u(t)
            + 0.1

    with u(t) ~ Uniform(0, 0.5).

    Because IT2F-RVFL-A itself is not a recurrent state-space network,
    delayed observations are explicitly supplied to the model:

        X(t) =
        [y(t), ..., y(t-9), u(t), ..., u(t-9)]

        target = y(t+1)

    Thus, the default input dimension is 20.

    Returns
    -------
    trainX : (n_train, 20)
    trainY : (n_train, 1)
    testX  : (n_test, 20)
    testY  : (n_test, 1)
    """
    if order != 10:
        raise ValueError(
            "This function implements NARMA-10 specifically; use order=10."
        )

    rng = np.random.default_rng(seed)
    total_supervised = n_train + n_test

    # Extra samples are needed for warm-up and 10 delayed values.
    total_steps = warmup + total_supervised + order + 2

    u = rng.uniform(input_low, input_high, size=total_steps)
    y = np.zeros(total_steps, dtype=float)

    # y[t+1] depends on y[t],...,y[t-9] and u[t],u[t-9].
    for t in range(order - 1, total_steps - 1):
        y_window = y[t - order + 1 : t + 1]
        y[t + 1] = (
            0.3 * y[t]
            + 0.05 * y[t] * np.sum(y_window)
            + 1.5 * u[t - order + 1] * u[t]
            + 0.1
        )

    start_t = warmup + order - 1

    X = np.empty((total_supervised, 2 * order), dtype=float)
    Y = np.empty((total_supervised, 1), dtype=float)

    for j in range(total_supervised):
        t = start_t + j

        # Most recent value first:
        # [y(t), y(t-1), ..., y(t-9)]
        y_lags = y[t - np.arange(order)]

        # [u(t), u(t-1), ..., u(t-9)]
        u_lags = u[t - np.arange(order)]

        X[j, :] = np.concatenate([y_lags, u_lags])
        Y[j, 0] = y[t + 1]

    return _chronological_split(X, Y, n_train, n_test)

