from functools import lru_cache
import numpy as np
from additional_dynamical_systems import generate_mackey_glass, generate_lorenz, generate_narma10

SYSTEM_NAMES=("FengNonlinearSystem","Mackey-Glass","Lorenz","NARMA-10")

def generate_eq58(seed: int = 42):
    """Reproduce the uploaded Eq. 58 generator + supervised preparation."""
    total_steps = 5200
    y = np.zeros(total_steps, dtype=float)
    x = np.zeros(total_steps, dtype=float)

    # Preserve the uploaded RandomState/np.random.seed sequence exactly.
    rng = np.random.RandomState(seed)
    for t in range(5000):
        val = rng.uniform(-2.0, 2.0)
        noise = rng.uniform(-0.2, 0.2)
        x[t] = val + noise

    for t in range(5000, total_steps):
        x[t] = np.sin(2.0 * np.pi * t / 25.0)

    for t in range(2, total_steps):
        y1 = y[t - 1]
        y2 = y[t - 2]
        numerator = y1 * y2 * (y1 + 2.5)
        denominator = 1.0 + y1 * y1 + y2 * y2
        y[t] = numerator / denominator + x[t - 1]

    # Uploaded dataset_preparation.py:
    # [y(t-1), y(t-2), x(t-1)] -> y(t)
    inputs = np.column_stack([y[1:-1], y[:-2], x[1:-1]])
    outputs = y[2:].reshape(-1, 1)

    train_limit = 5000 - 2
    return (
        inputs[:train_limit].copy(),
        outputs[:train_limit].copy(),
        inputs[train_limit:].copy(),
        outputs[train_limit:].copy(),
    )

def chronological_train_validation_split(X, Y, val_fraction: float = 0.20):
    X = np.asarray(X, dtype=float)
    Y = np.asarray(Y, dtype=float)
    n = X.shape[0]
    cut = int(np.floor((1.0 - float(val_fraction)) * n))
    if cut <= 0 or cut >= n:
        raise ValueError("Invalid chronological validation split.")
    return X[:cut], Y[:cut], X[cut:], Y[cut:]

@lru_cache(maxsize=4)
def load_system(name):
    if name == 'FengNonlinearSystem': return generate_eq58()
    if name == 'Mackey-Glass': return generate_mackey_glass()
    if name == 'Lorenz': return generate_lorenz(target='x')
    if name == 'NARMA-10': return generate_narma10()
    raise ValueError(f'Unknown system: {name!r}')
