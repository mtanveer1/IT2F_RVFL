import torch
import numpy as np

def t2f_f(X, RuleNum, seed=42): 
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    torch.manual_seed(seed)
    np.random.seed(seed)

    if not isinstance(X, torch.Tensor):
        X = torch.tensor(X, dtype=torch.float64)
    
    X = X.to(device)
    
    InDim = X.shape[1]
    Center1 = (0.5 * torch.rand(InDim, RuleNum,dtype=torch.float64, device=device)).requires_grad_(False)
    Center2 = (0.5 * torch.rand(InDim, RuleNum,dtype=torch.float64, device=device) + 0.5).requires_grad_(False)
    Width = torch.full((InDim, RuleNum), 0.5,dtype=torch.float64, device=device).requires_grad_(False)

    W1 = torch.rand(RuleNum, RuleNum,dtype=torch.float64, device=device).requires_grad_(False) 
    W2 = torch.rand(RuleNum, RuleNum,dtype=torch.float64, device=device).requires_grad_(False) 
    
    if X.dim() == 1:
        X = X.unsqueeze(0)

    B = X.shape[0]

    x = X.unsqueeze(2)                # [B, N, 1]
    c1 = Center1.unsqueeze(0)         # [1, N, R]
    c2 = Center2.unsqueeze(0)
    w  = Width.unsqueeze(0)
    # Membership Function 1
    cond1 = x <= c1
    cond2 = (x <= c2) & (x > c1)
    gauss1 = torch.exp(-((x - c1) ** 2) / (2 * w ** 2))
    gauss2 = torch.exp(-((x - c2) ** 2) / (2 * w ** 2))
    flat = torch.ones_like(gauss1)
    MemFun1 = torch.where(cond1, gauss1, torch.where(cond2, flat, gauss2)) 
    cond3 = x > (c1 + c2)/2
    MemFun2 = torch.where(cond3, gauss1, gauss2) 
    RuleAct1 = MemFun1.prod(dim=1)  # [B, R]
    RuleAct2 = MemFun2.prod(dim=1)  # [B, R]
    Weighted1 = RuleAct1 @ W1       # [B, OutDim]
    Weighted2 = RuleAct2 @ W2       # [B, OutDim]

    SumAct1 = RuleAct1.sum(dim=1, keepdim=True)
    SumAct2 = RuleAct2.sum(dim=1, keepdim=True)
    Norm1 = Weighted1 / (SumAct1 + 1e-8)
    Norm2 = Weighted2 / (SumAct2 + 1e-8)
    Output = (Norm2 + Norm1) / 2

    return Output.detach().cpu().numpy()





